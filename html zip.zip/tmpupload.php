<?php
//$allowed = array("txt", "jpg", "png", "doc", "zip", "html", "gif", "pdf", "docx", "odt", "text","jpeg");
	
	
	//$extension = end(explode(".", $_FILES["upload"]["type"]));
/*$file_ext= explode('.', $type);
$file_ext= strtolower(end($file_ext));
	
	
	
	$allowed = array(
  	'pdf', 
    'doc', 
    'docx',
    'png'
); 
	$allowedMimeTypes = array( 
    'application/msword',
    'text/pdf',
    'image/gif',
    'image/jpeg',
    'image/png'
);



if ( 2000000 < $_FILES["upload"]["size"]  ) {
  die( 'Please provide a smaller file [E/1].' );
}


if ( in_array( $file_ext, $allowed ) ) 
{      
  die('Please provide another file type [E/2].');
}

if ( in_array( $_FILES["upload"]["type"], $allowedMimeTypes ) ) 
{      
 move_uploaded_file($_FILES["upload"]["tmp_name"], "monday/" . $_FILES["file"]["name"]); 
}
else
{
die('Please provide another file type [E/3].');
}
	
	//$file_ext= explode('.', $name);
	//$file_ext= strtolower(end($file_ext));
	//print_r($file_ext);
	
	 
	//if(($type =="image/jpg") || ($type =="image/jpeg") || ($type =="image/png") || ($type =="application/msword")){
	 	 
	 
	 //echo"This file type is allowed";
	 
	 //}else{
	 
	 //echo "This file type $type is not allowed";
	 //}
	 
	 
	 
	 
	 
	 
	 
	 
	 //$allowed= array('txt', 'jpg', 'png', 'doc', 'zip', 'html', 'gif', 'pdf', 'docx', 'odt', 'text','jpeg');
	 	 
	 /*$check == FALSE;
	 
	 
	 $check = array_search($allowed,$type);
	 
	 if ($check){
	 
	 
	 echo"This file type is allowed";
	 
	 }else//{
	 
	 echo "This file type $type is not allowed";
	 print_r($check);

	 
	 //}
	 
	 
	 
	// if($type == $allowed){
	 
	 
	 
	 //}*/
	
}

	


	



else{

header("location: poetry.php");
}



?>




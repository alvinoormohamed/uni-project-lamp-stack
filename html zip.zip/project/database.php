<?php
$cn=mysql_connect("localhost","root","Danny123") or die("Could not Connect My Sql");
mysql_select_db("projectdb",$cn)  or die("Could not connect to Database");
?>

<?php
session_start();

if(isset($_SESSION['alogin']))
	{
		$user=$_SESSION['alogin'];
	}else

	{
		header("location:login.php");
	}

$name=$_GET['nama'];
download($name);

function download($name){
$file = $name_fail;




//$id = $_GET['file_id'];

 if (file_exists($file)){
	header('Content-Description: File Transfer');
	header('Content-Type: application/force-download');
	header("Content-Disposition: attachment; filename=\"" . basename($name) ."\";");
	header('Content-Transfer-Encoding: binary');
	header('Expires: 0');
	header('Cache-Control: must-revalidate');
	header('Content-Length:' .filesize($name));
	ob_clean();
	flush();
	readfile("monday/".$name);
 

 } 
}




/*$query = "select * from mst_monday where file_id='$id'";
$result = mysqli_query($cn, $query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($cn), E_USER_ERROR);
while($ros= mysqli_fetch_array($result))*/



//$path = $ros['path'];
// header("content-Disposition: attachment/ name= '.$path.'");
 //header("content-type: application/octet-stream");
 //header("content-length=".size($path));
 //readfile($path);


?>

<?php

session_start();

if(isset($_SESSION['login']))
	{
		$user=$_SESSION['login'];
	}else

	{
		header("location:login.php");
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Poetry</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
include("header.php");
include("database.php");

$res ="select * from mst_monday ";
$result = mysqli_query($cn, $res) or trigger_error("Query Failed! SQL: $res - Error: ". mysqli_error($cn), E_USER_ERROR);
echo "<table>";
while($row= mysqli_fetch_array($result))

	{
	
	echo "<tr>";
	echo "<td>"; echo $row['filename']; echo "</td>";
	echo "<td>";?><a href="<?php echo $row['path']?>">Download</a><?php echo "</td>";
	
	echo "</tr>";
		//$type = $row['type'];
		//echo $name;
		//echo '<img src="'.$name.'" >';
	
	}
echo "</table>";

?>
<!--<a href="download.php?filename=<?php echo $name ;?>">
<?php echo $name;?>download</a>	-->
</body>
</html>

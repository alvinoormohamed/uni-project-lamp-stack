<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>User Signup</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
include("header.php");
extract($_POST);
include("database.php");
$password = hash('sha256', $pass);
$query = "select * from mst_user where login='$loginid'";
$result = mysqli_query($cn, $query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($cn), E_USER_ERROR);
/*$rs=mysqli_query("select * from mst_user where login='$lid'");*/
if (mysqli_num_rows($rs)>0)
{
	echo "<br><br><br><div class=head1>Login Id Already Exists</div>";
	exit;
}
$query="insert into mst_user(user_id,login,pass,username,address,city,phone,email) values('$uid','$lid','$password','$name','$address','$city','$phone','$email')";
$result = mysqli_query($cn, $query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($cn), E_USER_ERROR);
echo "<br><br><br><div class=head1>Your Login ID  $lid Created Sucessfully</div>";
echo "<br><div class=head1>Please Login using your Login ID to take Quiz</div>";
echo "<br><div class=head1><a href=login.php>Login</a></div>";


?>
</body>
</html>


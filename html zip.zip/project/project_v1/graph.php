
<!--https://ndesostyle.wordpress.com/2014/02/21/google-chart-php-mysql/-->

<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <!--<style>
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) 
    .row.content {height: 1500px}
    
    /* Set gray background color and 100% height 
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding 
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid 
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;} 
    }*/
  </style>-->
</head>
<body>
<?php
include("header.php");
?>
<!--<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <h4></h4>
      <ul class="nav nav-pills nav-stacked">
<li ><a href="hackneysolutions/dashboard3.php" >Home</a></li>
<li ><a href="backend_blog.php" >Blog</a></li>
<li ><a href="graphdata.php">Graphs - Accidents</a></li>
<li ><a href="graph3.php">Graphs - Age</a></li>
<li ><a href="graphdata.php">Graphs - Hire</a></li>
<li ><a href="showbooking.php">Meetings</a></li>
<li ><a href="showclients.php">Users</a></li>
<li ><a href="showclaimform.php">Claims</a></li>
<li ><a href="contactus.html">Uploaded Documents</a></li>
<li ><a href="contactus.html">Uploaded Images</a></li>
<li ><a href="https://dashboard.zopim.com/?lang=en-us#home">Live Chat</a></li>
      </ul><br>
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search Blog..">
        <span class="input-group-btn">
          <button class="btn btn-default" type="button">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </span>
      </div>
    </div>-->

    <div class="col-sm-9">
      <h4><small>Bar Chart</small></h4>
      <hr>


   <div id="chart1">
 
<?php
$con=mysql_connect("localhost","root","Danny123") or die("Not Connecting Please Check again");
mysql_select_db("projectdb", $con);
$sth = mysql_query("SELECT login, test_id, score FROM mst_result");
 
$rows = array();

$table = array();
$table['cols'] = array(
 
    // Labels for your chart, these represent the column titles
    // Note that one column is in "string" format and another one is in "number" format as pie chart only required "numbers" for calculating percentage and string will be used for column title
    array('label' => 'login', 'type' => 'string'),
    array('label' => 'score', 'type' => 'number')
 
);
 
$rows = array();
while($r = mysql_fetch_assoc($sth)) {
    $temp = array();
    // the following line will be used to slice the Pie chart
    $temp[] = array('v' => (string) $r['login']); 
   
 
    // Values of each slice
    $temp[] = array('v' => (int) $r['score']);
    $rows[] = array('c' => $temp);
}
 
$table['rows'] = $rows;
$jsonTable = json_encode($table);
//echo $jsonTable;
?>
 
<html>
  <head>
    <!--Load the Ajax API-->
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript">
 
    // Load the Visualization API and the piechart package.
    google.load('visualization', '1', {'packages':['corechart']});
 
    // Set a callback to run when the Google Visualization API is loaded.
    google.setOnLoadCallback(drawChart);
 
    function drawChart() {
 
      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
      var options = {
           title: ' results ',
          is3D: 'true',
          width: 800,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
     // var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
      //chart.draw(data, options);
	var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	chart.draw(data, options); 

    }

    </script>
</div>

</body>
</html>









  </head>
 
  <body>
    <!--this is the div that will hold the pie chart-->
    <div id="chart_div"></div>
  </body>
</html>

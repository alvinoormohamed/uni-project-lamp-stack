<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html>
	<head>
		<title>English EQ</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	
	
 
    <div class="nav">
      <ul>
        
        <li class="contact"><a href="sublist.php">Tests</a></li>
		<li class="poetry"><a href="spoetry.php">Poetry</a></li>
        <li class="LetterWriting"><a href="sletter.php">Letter Writing</a></li>
        <li class="ShortStories"><a href="sstory.php">Short Stories</a></li>
        <li class="Comprehension"><a href="comp.php">Comprehension</a></li>
        
        
      </ul>
    </div>
 



<body class="news">



<!--<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}

</style>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="image/topbkg.jpg">
  <tr>
    <td width="90%" valign="top">
<!--You can modify the text, color, size, number of loops and more on the flash header by editing the text file (fence.txt) included in the zip file.-->

  <Table width="100%">
  <tr>
  <td>
  <?php @$_SESSION['login']; 
  error_reporting(1);
  ?>
  </td>
    <td>
	<?php
	if(isset($_SESSION['login']))
	{
	 echo "<div align=\"right\"><strong><a href=\"login.php\"> Home </a>|<a href=\"signout.php\">Signout</a></strong></div>";
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
	</td>
	
  </tr>
  
</table>

<?php

session_start();

if(isset($_SESSION['alogin']))
	{
		$user=$_SESSION['alogin'];
	}else

	{
		header("location:login.php");
	}
include("header.php");
include("database.php");




if($_POST['submit']){
	
	

	$name = $_FILES['file']['filename'];
	$tmp_name = $_FILES['file']['tmp_name'];
	$type = $_FILES['file']['type'];
	$size = $_FILES['file']['size'];
	$path = "monday/".$name;
		 
	if(($type =="image/jpg") || ($type =="image/jpeg") || ($type =="image/png") || ($type =="application/msword")){
	 echo"<img src='monday/$name'>";	 
	 	 	 
		if($size <= 400000){
		
		echo $tmp_name;
		echo "monday/".$name;
		
		move_uploaded_file($tmp_name, "monday/".$name);
		
		$query="insert into mst_monday(filename,size,type,path) values('$name','$size','$type','$path')";                        
        $result = mysqli_query($cn, $query) or trigger_error("Query Failed! SQL: $query - Error: ". mysqli_error($cn), E_USER_ERROR);
        $data = mysqli_query ($cn, $query);

if ($data)
{
	echo "YOUR UPLOAD IS COMPLETE <br>";
}
		}else{
		
		echo "The File: $name is Too large....<br>
		The Size is $size and needs to be less than 300kb";
		
		
		}
	
	
	}else{
	 
	echo "This file type $type is not allowed";
	}
	 	 	 
	
}





else{

header("location: poetry.php");
}



?>



























































	

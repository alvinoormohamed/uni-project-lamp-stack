<?php
session_start();

if(isset($_SESSION['alogin']))
	{
		$user=$_SESSION['alogin'];
	}else

	{
		header("location:login.php");
	}
?>
<!--https://ndesostyle.wordpress.com/2014/02/21/google-chart-php-mysql/-->

<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  
</head>
<body>
<?php
include("header.php");
?>


    <div class="col-sm-9">
      <h4><small>Bar Chart</small></h4>
      <hr>


   <div id="chart1">
 
<?php
$con=mysql_connect("localhost","root","Danny123") or die("Not Connecting Please Check again");
mysql_select_db("projectdb", $con);
$sth = mysql_query("SELECT login, score FROM mst_result");
 
$rows = array();

$table = array();
$table['cols'] = array(
 
    // Labels for your chart, these represent the column titles
    // Note that one column is in "string" format and another one is in "number" format as pie chart only required "numbers" for calculating percentage and string will be used for column title
    array('label' => 'login', 'type' => 'string'),
    array('label' => 'score', 'type' => 'number')
 
);
 
$rows = array();
while($r = mysql_fetch_assoc($sth)) {
    $temp = array();
    // the following line will be used to slice the Pie chart
    $temp[] = array('v' => (string) $r['login']); 
   
 
    // Values of each slice
    $temp[] = array('v' => (int) $r['score']);
    $rows[] = array('c' => $temp);
}
 
$table['rows'] = $rows;
$jsonTable = json_encode($table);
//echo $jsonTable;
?>
 
<html>
  <head>
    <!--Load the Ajax API-->
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript">
 
    // Load the Visualization API and the piechart package.
    google.load('visualization', '1', {'packages':['corechart']});
 
    // Set a callback to run when the Google Visualization API is loaded.
    google.setOnLoadCallback(drawChart);
 
    function drawChart() {
 
      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
      var options = {
           title: ' results ',
          is3D: 'true',
          width: 800,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
     // var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
      //chart.draw(data, options);
	var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	chart.draw(data, options); 

    }

    </script>
</div>

</body>
</html>









  </head>
 
  <body>
    <!--this is the div that will hold the pie chart-->
    <div id="chart_div"></div>
  </body>
</html>

<?php

$file_result = "";

if ($_FILES["file"]["error"] > 0)
{

$file_result .= "No Files Uploaded or Invalid File";
$file_result .= "Error Code: " . $_FILES["file"]["error"] . "<br>";

}else{

$file_result .=

"Upload: " . $_FILES["file"]["name"] . "<br>" .
"Type: " . $_FILES ["file"]["type"] . "<br>" .
"Size: "


}

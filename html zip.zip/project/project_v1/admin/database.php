<?php

	$dbusername = "root";
    $dbpassword = "Danny123";
    $dbhost = "localhost";
    $dbname = "projectdb";

$cn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname) or die('MySQL connect failed. ' . mysqli_connect_error());



/*$cn=mysql_connect("localhost","root","Danny123") or die("Could not Connect My Sql");
mysql_select_db("projectdb",$cn)  or die("Could not connect to Database");*/
?>

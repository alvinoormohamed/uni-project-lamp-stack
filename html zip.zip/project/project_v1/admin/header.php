<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../quiz.css" rel="stylesheet" type="text/css">
</head>

<body>
<html>
	<head>
		<title>English EQ</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	
	<body class="news">
  <header>
    <div class="nav">
      <ul>
        
        
		<li class="poetry"><a href="poetry.php">Poetry</a></li>
        <li class="LetterWriting"><a href="letter.php">Letter Writing</a></li>
        <li class="ShortStories"><a href="shortstory.php">Short Stories</a></li>
        <li class="Comprehension"><a href="comprehension.php">Comprehension</a></li><br>
        <li class="contact"><a href="graph.php">Graphs</a></li>
        
      </ul>
    </div>
  </header>
<!--<style type="text/css">-->
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
-->
</style>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="90%" valign="top">


<div align="left"><object classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000
codebase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,2,0
width=500
height=68>

  </tr>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#000000">
  <tr>
    <td width="100%"><img border="0"  width="89" height="15"></td>
  </tr>
</table>
  <table width="100%">
  <tr>
    <td aling=right>
	<?php
	if(isset($_SESSION['alogin']))
	{
	 echo "<div align=\"right\"><strong><a href=\"login.php\">Admin Home</a>|<a href=\"signout.php\">Signout</a></strong></div>";
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
	</td>
  </tr>
</table>
